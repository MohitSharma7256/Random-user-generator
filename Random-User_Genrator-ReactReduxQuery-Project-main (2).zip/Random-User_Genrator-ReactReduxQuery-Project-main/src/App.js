import React from "react";
import UsersComp from "./Components/UsersComp";

function App() {
  return (
    <div className="App">
      <UsersComp />
    </div>
  );
}

export default App;
